import React from 'react'
import Map from '../components/Map/Map'
// import Tree from '../components/Tree/Tree'

export default function Home() {
  return (
    <>
      <div>home that home</div>
      <Map></Map>
      {/* <Tree></Tree> */}
    </>
    
  )
}
