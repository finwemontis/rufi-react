import React from 'react'

export default function OrthSeq() {
  return (
    <div>orthSeq</div>
  )
}
