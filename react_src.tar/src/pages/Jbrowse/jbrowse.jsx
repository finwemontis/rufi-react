import React from 'react'
import Jb from './Jb_test/Jb'
import Jb2 from './Jb_test_r/Jb'
// import JbComponent from './JB2/JbComponent'

export default function Jbrowse() {
  
  return (
    <>
      <div>theoradically here will be some something pops out. </div>
      <Jb></Jb>
      <Jb2></Jb2>
    </>
  )
}
