import React from 'react'

export default function Download() {
  return (
    <div>download</div>
  )
}
