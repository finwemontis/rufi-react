import React, { Component } from 'react'

export default class News extends Component {
  render() {
    return (
      <ul>
        <li>new1</li>
        <li>new2</li>
        <li>new3</li>
      </ul>
    )
  }
}
