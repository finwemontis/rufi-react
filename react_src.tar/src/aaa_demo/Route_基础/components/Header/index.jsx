import React, { Component } from 'react'

export default class Header extends Component {
  render() {
    return (
      <div>
        <h2>Hello this is header</h2>
      </div>
    )
  }
}
