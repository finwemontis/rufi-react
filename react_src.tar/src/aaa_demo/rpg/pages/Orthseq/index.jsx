import React, { Component } from 'react'

export default class index extends Component {
  render() {
    return (
      <div>gene seqs of 同源基因</div>
    )
  }
}
