import React, { useEffect, useState } from 'react'

export default function ChartBeforeLoad() {
  return (
    <div>ChartBeforeLoad</div>
  )
}