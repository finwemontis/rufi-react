import React from 'react'

export default function VarSelection() {
  return (
    <div>VarSelection</div>
  )
}
